# praogram to read a file
f=open("demo1.txt","r")
print(f.read())
